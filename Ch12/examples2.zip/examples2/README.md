# AdByeBye 廣告掰掰外掛

# What are extensions?

Extensions are small software programs that can modify and enhance the functionality of the Chrome browser. You write them using web technologies such as HTML, JavaScript, and CSS.

# 延伸閱讀
1. [What are extensions?](https://developer.chrome.com/extensions)
2. [大兜的 Chrome Extension 學習筆記](https://tonytonyjan.net/2012/05/25/get-start-with-chrome-extension/)
3. [window.onload vs document.onload](http://stackoverflow.com/questions/588040/window-onload-vs-document-onload)